#!/bin/bash
set -eu
set -x

CASSANDRA_DIR=/opt/cassandra_data
NODETOOL=/usr/local/bin/bznodetool
STAGINGDIR=/opt/cassandrabackup/incrementals
S3BUCKET=bzbackup-cassandra-incremental

HOSTNAME=$(/bin/hostname)
BACKUPTIME=$(/bin/date +%Y%m%d-%H%M)

echo "Cleaning up staging dir"
/bin/rm -f $STAGINGDIR/*.tar.bz2 || true
/bin/rm -f $STAGINGDIR/*.tar.bz2.gpg || true
/bin/rm -f $STAGINGDIR/*.incremental.tar.bz2.files.txt

for keyspace in $(ls $CASSANDRA_DIR/data); do
    for tabledir in $(ls $CASSANDRA_DIR/data/$keyspace/); do
        table=$(echo $tabledir | cut -d- -f1)
        backupsource="$CASSANDRA_DIR/data/$keyspace/$tabledir/backups/"
        if [ ! -d $backupsource ]; then
            echo "Skipping $keyspace/$tabledir because no backups dir found"
            continue
        fi
        backupfilename="$(/bin/hostname)-$keyspace-$table-$BACKUPTIME-incremental.tar.bz2"
        filelist=$(find $backupsource -type f)
        # unlike snapshots, we don't have a nice clean directory that won't change
        # so build a list of files to back up and only clean those up
        echo "$filelist" > "$STAGINGDIR/${backupfilename}.files.txt"
        if ! /bin/grep -q 'db' "$STAGINGDIR/${backupfilename}.files.txt"; then
            echo "$tabledir has no incrementals, skipping it"
            /bin/rm "$STAGINGDIR/${backupfilename}.files.txt";
            continue
        fi
	# Using bsdtar instead of GNU.  Cassandra sometimes removes the original db
        # file due to compaction, which causes GNU tar to freak out.
        echo "Tarring up $backupsource and copying to S3"
        filesize_guess=$(du -bs $backupsource | awk '{print $1}')
        s3backupdest="s3://$S3BUCKET/$(/bin/hostname)-$keyspace-$table-$BACKUPTIME.tar.bz2.gpg"
        attempts=1
        until /usr/bin/bsdtar -n -c -f - -T "$STAGINGDIR/${backupfilename}.files.txt" -C $backupsource . | /usr/bin/nice /usr/bin/pbzip2 -p4 | /usr/bin/gpg --encrypt --trust-model always -r bzcassandra@backblaze.com -z0 | /usr/local/bin/aws --profile cassandrabackup s3 cp --expected-size $filesize_guess - $s3backupdest; do
        (( $attempts >= 20 )) && exit 1
            echo "Transfer failed, retrying in 30s"
            sleep 30
            attempts=$(( attempts + 1 ))
        done
        for deletefile in $filelist; do
            /bin/rm "$deletefile"
        done
        echo "Cleaning up $STAGINGDIR/${backupfilename}.files.txt"
        /bin/rm "$STAGINGDIR/${backupfilename}.files.txt"
    done
done
# Once everything's totally successfully done, create a "done" file
# that we can use for monitoring
echo "$BACKUPTIME" > $STAGINGDIR/${HOSTNAME}_backup_complete
/usr/local/bin/aws --profile cassandrabackup s3 cp $STAGINGDIR/${HOSTNAME}_backup_complete s3://$S3BUCKET/

