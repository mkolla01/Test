#!/usr/bin/env python
#
# File: cassandra_to_prometheus
#
# Copyright 2016, Backblaze Inc.  All rights reserved.
#

"""
Runs 'nodetool status' and 'nodetool tablestats'.  Scrapes out
interesting info and pushes it to the prometheus gateway.

Makes sure that only one instance is running.
"""

import argparse
import datetime
import json
import logging
import logging.handlers
import os
import prometheus_client
import re
import socket
import subprocess
import sys
import time

# what port should we grab to make sure there's at most one copy of
# this running on a machine?
# see $BZ_UNIVERSE/bzmono/datacenter/config_mgmt/ansible/README_BATON_PORTS.txt to pick a port
BATON_PORT = 1237  # /etc/services says that's tsdos390.

NODETOOL = '/usr/local/bin/bznodetool'

def read_json_if_present(path, logger):
    try:
        with open(path, 'rb') as f:
            return json.load(f)
    except Exception as e:
        logger.warn('could not load json from %s: %s' % (path, repr(e)))
        return {}


def make_logger():
    LOG_FILE = '/bzsite/commonlogs/cassandra_to_prometheus/log'
    LOG_DIR = os.path.dirname(LOG_FILE)
    if not os.path.isdir(LOG_DIR):
        os.makedirs(LOG_DIR)

    formatter = logging.Formatter(fmt='%(asctime)s %(levelname)s %(name)s %(message)s')

    file_handler = logging.handlers.RotatingFileHandler(filename=LOG_FILE, maxBytes=1000000, backupCount=5)
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)

    logger = logging.getLogger('cassandra_to_prometheus')
    logger.setLevel(logging.INFO)
    logger.propagate = False
    logger.addHandler(file_handler)
    return logger


def get_instance():
    result = subprocess.check_output(['hostname']).strip()
    if result.endswith('.local'):
        result = result[:-6]
    return result

def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

class Metrics(object):

    def __init__(self, logger):
        self.logger = logger
        self.instance = get_instance()
        self.registry = prometheus_client.CollectorRegistry()
        self.cassandra_to_prometheus_duration_seconds = self._make_gauge(
            'cassandra_to_prometheus_duration_seconds',
            'duration to execute a task cassandra_to_prometheus',
            ['instance', 'task']
        )
        self.cassandra_nodes_down_total = self._make_gauge(
            'cassandra_nodes_down_total',
            'how many nodes in the cluster are down',
            ['instance']
        )
        self.cassandra_local_latency_seconds = self._make_gauge(
            'cassandra_local_latency_seconds',
            'read or write latence on the local node',
            ['instance', 'table', 'action', 'percentile']
        )
        self.cassandra_local_action_total = self._make_counter(
            'cassandra_local_action_total',
            'number of reads/writes',
            ['instance', 'table', 'action']
        )
        self.cassandra_sstables_at_level_total = self._make_gauge(
            'sstables_at_level_total',
            'number of sstables at each level of a table',
            ['instance', 'table', 'level']
        )
        self.cassandra_disk_used_fraction = self._make_gauge(
            'cassandra_disk_used_fraction',
            'what fraction of the cassandra drive is used',
            ['instance']
        )
        self.cassandra_disk_used_blocks = self._make_gauge(
            'cassandra_disk_used_blocks',
            'what is the space on cassandra drive is used',
            ['instance']
        )
        self.cassandra_disk_total_blocks = self._make_gauge(
            'cassandra_disk_total_blocks',
            'What is the total space allocated to cassandra drive',
            ['instance']
        )
        self.cassandra_dropped_action_total = self._make_counter(
            'cassandra_dropped_action_total',
            'number of actions dropped',
            ['instance', 'action']
        )
        self.cassandra_gc_time_fraction = self._make_gauge(
            'cassandra_gc_time_fraction',
            'fraction of the time spent doing GC',
            ['instance']
        )
        self.cassandra_error_count_in_last_hour = self._make_gauge(
            'cassandra_error_count_in_last_hour',
            'number of ERRORs in the logs in the last hour',
            ['instance']
        )

    def timed_check_output(self, command, task):
        start_time = time.time()
        output = subprocess.check_output(command)
        labels = dict(instance=self.instance, task=task)
        duration = time.time() - start_time
        self.cassandra_to_prometheus_duration_seconds.labels(**labels).set(duration)
        self.logger.info('%s took %3.1f seconds' % (task, duration))
        return output

    def _make_gauge(self, metric_name, help_string, label_names=None):
        if label_names is None:
            label_names = []
        gauge = prometheus_client.Gauge(metric_name, help_string, label_names)
        self.registry.register(gauge)
        return gauge

    def _make_counter(self, metric_name, help_string, label_names=None):
        if label_names is None:
            label_names = []
        counter = prometheus_client.Counter(metric_name, help_string, label_names)
        self.registry.register(counter)
        return counter


def acquire_baton():
    """
    Tries to listen on the BATON_PORT.  If that works, we're allowed
    to run.

    No effort is made to close the sockt.  That will happen when the
    process exits.
    """
    try:
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind(('localhost', BATON_PORT))
        return server_socket
    except:
        return None


counters_that_have_been_set = set()


def set_counter(counter, labels, value):
    # Counters don't have a set() method.  We want set(), because
    # we are reading a counter from Cassandra.  We happen to know
    # that each time this script runs, the counter starts at 0, so
    # inc() is the same as set().  Yuck.
    time_series_name = tuple([counter._name] + [k + ':' + v for (k,v) in sorted(labels.items())])
    assert time_series_name not in counters_that_have_been_set
    counters_that_have_been_set.add(time_series_name)
    counter.labels(**labels).inc(value)


def check_nodetool_status(metrics):
    output = metrics.timed_check_output([NODETOOL, 'status'], 'nodetool_status')

    have_dashes = False
    up_count = 0
    down_count = 0
    for line in output.split('\n'):
        line = line.strip()
        if line != '':
            if have_dashes and not line.startswith('Note'):
                if line.startswith('UN'):
                    up_count += 1
                else:
                    down_count -= 1
                    metrics.logger.warn('node is down: ' + line)
            if line.startswith('--'):
                have_dashes = True
    down_count = max(down_count, 3 - up_count)
    labels = dict(instance=metrics.instance)
    metrics.cassandra_nodes_down_total.labels(**labels).set(down_count)
    metrics.logger.info('down_count = %d' % down_count)


def check_nodetool_cfstats_cfhistograms(metrics):
    output = metrics.timed_check_output([NODETOOL, 'tablestats'], 'nodetool_cfstats')
    current_keyspace = None
    current_table = None
    table_is_index = False
    for line in output.split('\n'):
        line = line.strip()
        parts = line.split(':')
        if len(parts) == 2:
            key = parts[0].strip()
            value = parts[1].strip()
            if key == 'Keyspace':
                current_keyspace = value
            if key == 'Table':
                table_is_index = False
                current_table = '%s.%s' % (current_keyspace, value)
                if current_keyspace not in ['system_traces', 'system_auth', 'system']:
                        check_nodetool_cfhistograms(metrics, current_keyspace, value)
            if key == 'Table (index)':
                table_is_index = True
            if table_is_index:
                continue
            if key == 'Local read count':
                labels = dict(instance=metrics.instance, table=current_table, action='read')
                set_counter(metrics.cassandra_local_action_total, labels, int(value))
            if key == 'Local write count':
                labels = dict(instance=metrics.instance, table=current_table, action='write')
                set_counter(metrics.cassandra_local_action_total, labels, int(value))
            if key == 'SSTables in each level':
                assert value.startswith('[') and value.endswith(']')
                counts = value[1:-1].split(', ')
                for (level, count) in enumerate(counts):
                    if '/' in count:
                        count = count.split('/')[0]
                    if count != '0':
                        labels = dict(instance=metrics.instance, table=current_table, level=level)
                        metrics.cassandra_sstables_at_level_total.labels(**labels).set(int(count))
       

def check_nodetool_cfhistograms(metrics, keyspace, tablename):
    output = metrics.timed_check_output([NODETOOL, 'tablehistograms', keyspace, tablename], 'nodetool_cfhistograms')
    for line in output.split('\n'):
        columns = line.split()
        full_tablename = "%s.%s" % (keyspace, tablename)
        pct_to_collect = [ '50', '75', '95', '99' ]
        for pct in pct_to_collect:
            if len(columns) > 0 and columns[0] == pct + '%':
                if is_number(columns[3]):
                    seconds = float(columns[3]) / 1000000 # tablehistograms reports microseconds
                    labels = dict(instance=metrics.instance, table=full_tablename, action='read', percentile=pct)
                    metrics.cassandra_local_latency_seconds.labels(**labels).set(seconds)
                if is_number(columns[2]):
                    seconds = float(columns[2]) / 1000000 # tablehistograms reports microseconds
                    labels = dict(instance=metrics.instance, table=full_tablename, action='write', percentile=pct)
                    metrics.cassandra_local_latency_seconds.labels(**labels).set(seconds)
 

def check_nodetool_tpstats(metrics):
    output = metrics.timed_check_output([NODETOOL, 'tpstats'], 'nodetool_tpstats')
    in_dropped_section = False
    for line in output.split('\n'):
        words = line.split()
        if in_dropped_section and len(words) == 2:
            (action, count_str) = words
            count = int(count_str)
            labels = dict(instance=metrics.instance, action=action)
            set_counter(metrics.cassandra_dropped_action_total, labels, count)
        if line.startswith('Message type'):
            in_dropped_section = True


def check_disk_usage(metrics):
    output = metrics.timed_check_output(['/bin/df', '/opt/cassandra_data'], 'df')
    fraction_used = 1.0
    for line in output.split('\n'):
        words = line.split()
        if 3 < len(words) and words[0].startswith('/dev/'):
            total_blocks = float(words[1])
            used_blocks = float(words[2])
            fraction_used = used_blocks / total_blocks
    labels = dict(instance=metrics.instance)
    metrics.cassandra_disk_used_fraction.labels(**labels).set(fraction_used)
    metrics.cassandra_disk_used_blocks.labels(**labels).set(used_blocks)
    metrics.cassandra_disk_total_blocks.labels(**labels).set(total_blocks)


def check_cassandra_log(metrics):
    """
    Scans the cassandra log file for interesting stuff in the past hour.

    Does not handle log rotation well.  Just reads the most recent log
    file, so right after rotation, it will not have a full hour.

    Log lines look like this:
        INFO  [Service Thread] 2016-10-28 15:31:14,673 GCInspector.java:252 - ParNew GC in 302ms.  CMS Old Gen: 714835256 -> 728727680; Par Eden Space: 335544320 -> 0; Par Survivor Space: 24940504 -> 25593640
        INFO  [Service Thread] 2016-10-26 13:39:36,706 GCInspector.java:252 - ConcurrentMarkSweep GC in 8335ms.  CMS Old Gen: 1025609152 -> 134371200; Par Eden Space: 335544320 -> 0; Par Survivor Space: 18649344 -> 0
    """
    # When was an hour ago?  The log is in local time, so this also runs
    # in local time.
    one_hour_ago = datetime.datetime.now() - datetime.timedelta(hours=1)
    date_one_hour_ago = one_hour_ago.strftime('%Y-%m-%d')
    time_one_hour_ago = one_hour_ago.strftime('%H:%M:%S')  # ignore sub-second time

    # When was 10 minutes ago?
    ten_minutes_ago = datetime.datetime.now() - datetime.timedelta(minutes=10)
    date_ten_minutes_ago = ten_minutes_ago.strftime('%Y-%m-%d')
    time_ten_minutes_ago = ten_minutes_ago.strftime('%H:%M:%S')  # ignore sub-second time

    # Pattern for pulling out date, time, and message:
    line_pattern = re.compile(r'^([A-Z]+) +\[[^\]]*] +([^ ]+) +([^ ]+) +(.*)')
    par_new_pattern = re.compile(r'.*GCInspector.*ParNew GC in (\d+)ms.*')
    mark_sweep_pattern = re.compile(r'.*GCInspector.*ConcurrentMarkSweep GC in (\d+)ms.*CMS Old Gen: \d+ -> (\d+).*')
    g1_new_pattern = re.compile(r'.*G1 Young Generation GC in (\d+)ms.*G1 Old Gen: \d+ -> (\d+).*')
    g1_old_pattern = re.compile(r'.*G1 Old Generation GC in (\d+)ms.*G1 Old Gen: \d+ -> (\d+).*')
    gc_patterns = [ par_new_pattern, mark_sweep_pattern, g1_new_pattern, g1_old_pattern ]

    # Scan the log for entries after an hour ago
    log_file = '/opt/cassandra/logs/system.log'
    error_count = 0
    gc_millis = 0
    old_gen_size = 0
    with open(log_file, 'rb') as f:
        for line in f:
            match = line_pattern.match(line)
            if match:
                level = match.group(1)
                date_str = match.group(2)
                time_str = match.group(3)
                message = match.group(4)

                match = mark_sweep_pattern.match(message)
                if match:
                    old_gen_size = int(match.group(2))
                else:
                    match = g1_old_pattern.match(message)
                    if match:
                        old_gen_size = int(match.group(2))

                if (date_one_hour_ago == date_str and time_one_hour_ago <= time_str) or (date_one_hour_ago < date_str):
                    if level == 'ERROR':
                        error_count += 1
                    if (date_ten_minutes_ago == date_str and time_ten_minutes_ago <= time_str) or (date_ten_minutes_ago < date_str):
                        if 'GCInspector' in message:
                            for pattern in gc_patterns:
                                match = pattern.match(message)
                                if match:
                                    gc_millis += int(match.group(1))
                                    found_match = True

    # These metrics all use just the instance as a label
    labels = dict(instance=metrics.instance)

    #  How many errors were in the logs?
    metrics.cassandra_error_count_in_last_hour.labels(**labels).set(error_count)

    # What fraction of the time has it spent in GC?
    ten_minutes_millis = 10 * 60 * 1000
    gc_fraction = float(gc_millis) / float(ten_minutes_millis)
    metrics.cassandra_gc_time_fraction.labels(**labels).set(gc_fraction)

    # We don't want to report anything if we didn't find an old gen size, so
    # only make the gauge if we're reporting something.
    if old_gen_size != 0:
        old_gen_size_gauge = metrics._make_gauge(
            'cassandra_old_gen_heap_size',
            'number of bytes in old gen heap area as of last GC',
            ['instance']
        )
        old_gen_size_gauge.labels(**labels).set(old_gen_size)


def gather_metrics(metrics):
    metrics_start_time = time.time()
    check_cassandra_log(metrics)
    check_nodetool_status(metrics)
    check_nodetool_cfstats_cfhistograms(metrics)
    check_nodetool_tpstats(metrics)
    check_disk_usage(metrics)
    labels = dict(instance=metrics.instance, task='all')
    metrics.cassandra_to_prometheus_duration_seconds.labels(**labels).set(time.time() - metrics_start_time)


def main():
    parser = argparse.ArgumentParser(description="push metrics to prometheus")
    parser.add_argument('host_and_port')
    args = parser.parse_args()

    baton = acquire_baton()
    if baton:
        logger = make_logger()
        try:
            metrics = Metrics(logger)
            logger.info('start gathering metrics')
            gather_metrics(metrics)
            logger.info('push to gateway')
            # print prometheus_client.generate_latest(metrics.registry)
            prometheus_client.push_to_gateway(args.host_and_port, job='cassandra', grouping_key={'instance':metrics.instance}, registry=metrics.registry)
            logger.info('done')
        except Exception as e:
            logger.error('exception: ' + repr(e))
            raise
    else:
        print 'could not acquire baton'

if __name__ == '__main__':
    main()
