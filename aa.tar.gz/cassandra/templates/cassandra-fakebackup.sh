#!/bin/bash
# This is a small stupid script whose only purpose is to generate
# fake "backup complete" entries for the host.  Why?  Because a brand
# new host may take up to a week to get around to running backups, which 
# means we have to leave monitoring disabled for that time.
# Instead, we make a fake backup 7 days in the future.
echo "Creating fake backup for 7 days from now to suppress alarms"
datestamp=$(/bin/date +%Y%m%d-%H%M -d "7 days")
echo $datestamp > /opt/cassandrabackup/snapshots/donefile_$(/bin/hostname)
/usr/local/bin/aws --profile cassandrabackup s3 cp /opt/cassandrabackup/snapshots/donefile_${HOSTNAME} s3://bzbackup_cassandra/
# make some fake files for the counter as well
for i in {1..28}; do
  touch /opt/cassandrabackup/$(hostname)-fake_backup-$i-$datestamp-.tar.bz2.gpg
  echo "uploading fake backup /opt/cassandrabackup/$(hostname)-fake_backup-$i-$datestamp-.tar.bz2.gpg"
  /usr/local/bin/aws --profile cassandrabackup s3 cp /opt/cassandrabackup/$(hostname)-fake_backup-$i-$datestamp-.tar.bz2.gpg s3://bzbackup_cassandra/
  rm /opt/cassandrabackup/$(hostname)-fake_backup-$i-$datestamp-.tar.bz2.gpg
done

