#!/bin/bash
/usr/local/bin/bznodetool snapshot -t bac12-$(/bin/date +%Y%m%d-%H%M) --column-family stave b2  &> /dev/null

