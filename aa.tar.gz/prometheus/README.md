# Prometheus Ansible Role
Deploys prometheus services and nginx frontend with LDAP auth for prometheus,
alertmanager, and pushgateway.

Includes
- prometheus
- alertmanager
- alerting rules
- pushgateway
- a script and cron that send prom data to zabbix

## Parameters
__WARNING__: The descriptions for `*_backend_port`s here are currently lies.
The backend services are also reachable without nginx, but this will change to
enforce auth to these services.
- `prometheus_frontend_port`: Required port number. The nginx port where
   prometheus will be reachable.
- `prometheus_backend_port`: Required port number. The localhost port where
   there the prometheus service will be bound to.
- `prometheus_alert_manager_frontend_port`: Required port number. The nginx port
   where alertmanager will be reachable.
- `prometheus_alert_manager_backend_port`: Required port number. The localhost
   port where there the alertmanager service will be bound to.
- `prometheus_push_gateway_frontend_port`: Required port number. The nginx port
   where pushgateway will be reachable.
- `prometheus_push_gateway_backend_port`: Required port number. The localhost
   port where there the pushgateway service will be bound to.
