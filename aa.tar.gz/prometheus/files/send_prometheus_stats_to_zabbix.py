#!/usr/bin/env python2
######################################################################
#
# File: send_prometheus_stats_to_zabbix.py
#
# Copyright 2016 Backblaze Inc. All Rights Reserved.
#
######################################################################

"""

"""

import argparse
import json
import requests
import collections
import unittest
import socket
import sys
import urllib

from pyzabbix import ZabbixMetric, ZabbixSender

# what port should we grab to make sure there's at most one copy of
# this running on a machine?  i picked 6123, because, well, it's the
# last four digits of my phone number.
# (IANA says it's "backup-express" and it seems unlikely we'd be using
# that anytime soon!)
BATON_PORT = 6123

# gets a value from an object (with dicts and arrays, like from json.load),
# walking down the path given by the arguments, using each argument as the
# index into each level.  it returns None if it there's no value for the
# given name at any point.  (it may also return None if the path leads
# to a value of None!)
def get_by_path(obj, *args):
    # http://stackoverflow.com/questions/2937114/python-check-if-an-object-is-a-sequence
    scan = obj
    for index in args:
        # print "looking for '%s' in %s" % (str(index), str(type(scan)))
        if isinstance(scan, dict):
            scan = scan.get(index)
        elif isinstance(scan, basestring):
            raise Exception("expected object or sequence, but got string!?")
        elif isinstance(scan, collections.Sequence):
            if 0 <= index < len(scan):
                scan = scan[index]
            else:
                # outside bounds of array
                scan = None
        if scan is None:
            return None
    return scan


class TestGetByPath(unittest.TestCase):
    def testDict(self):
        data = {'a': {'b': 5}}
        self.assertIsNone(get_by_path(data, 'z'))
        self.assertEqual(5, get_by_path(data, 'a', 'b'))

    def testSequence(self):
        data = [1, 2, [10, 20]]
        self.assertIsNone(get_by_path(data, -1))
        self.assertIsNone(get_by_path(data, 5))
        self.assertEqual(1, get_by_path(data, 0))
        self.assertEqual(20, get_by_path(data, 2, 1))


def send_zabbix_data(zabbix_server, zabbix_data):
    print "SENDING!...."
    ZabbixSender(zabbix_server, 10051).send(zabbix_data)


class Config(object):
    def __init__(self, config_file_name):
        super(Config, self).__init__()
        with open(config_file_name, "rb") as f:
            self.data = json.load(f)

    def get_mappings(self):
        mappings = get_by_path(self.data, "mappings")
        if mappings is None:
            raise Exception("config is missing 'mappings'")
        return mappings


USAGE = """This program reads values from prometheus and posts them to zabbix.
Use a config file to say what should be sent.
"""


def handle_args():
    parser = argparse.ArgumentParser(description=USAGE, formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('--prometheus', "-p", help='hostname of prometheus server (ie: sfmonitor-0001.backblaze.com', required=True)
    parser.add_argument('--zabbix', "-z", help='hostname of zabbix server (ie: monitor-sac0-0000', required=True)
    parser.add_argument('--host', "-t", help="the hostname for the metrics we're posting to zabbix", required=True)
    parser.add_argument('--config', "-c", help="the config file that says what to send.", required=True)
    parser.add_argument('--yes', "-y", action='store_true', help="really send? if not provided, we won't send.")
    parser.add_argument('--verbose', "-v", action='store_true', help="if provided, we print the metrics we would send.")
    parsed_args = parser.parse_args()
    return parsed_args


def get_value_from_prometheus(hostname, query):
    url = "http://%s:9090/api/v1/query?query=%s" % (hostname, urllib.quote_plus(query))
    print url

    response = requests.request('GET', url, timeout=5).json()
    print json.dumps(response)

    if get_by_path(response, "status") != "success":
        raise Exception("failed to fetch data from prometheus:\n%s\n%s" % (url, json.dumps(response)))

    data = get_by_path(response, "data")
    if data is None:
        raise Exception("no data?\n%s\n%s" % (url, json.dumps(response)))

    result_type = get_by_path(data, "resultType")
    if result_type != "vector":
        raise Exception("unexpected result type '%s':\n%s\n%s" % (result_type, url, json.dumps(response)))

    value = get_by_path(data, "result", 0, "value", 1)
    print 'value =', repr(value)
    if value is not None:
        value = float(value)
        print "value = %s (%s)" % (str(value), str(type(value)))
        return value
    else:
        # There was no value returned.  Maybe prometheus doesn't have the metric?
        # sometimes, right after a host has restarted, it has no metrics until
        # it actually has data.
        print 'No value present.  Not sending to Zabbix.'
        return None

def main():
    args = handle_args()

    config = Config(args.config)

    zabbix_metrics = []
    for mapping in config.get_mappings():
        value = get_value_from_prometheus(args.prometheus, mapping["prometheus_query"])
        if value is not None:
            metric = ZabbixMetric(args.host, mapping["zabbix_item_key"], value)
            zabbix_metrics.append(metric)

    # this is the item that we use to show we've been running.
    metric = ZabbixMetric(args.host, "prometheus_pusher_ran", 1)
    zabbix_metrics.append(metric)

    if args.verbose:
        # print str(zabbix_metrics)
        # print "\n".join(map(lambda x: x.key, zabbix_metrics))
        print "\n".join(map(lambda x: str(x), zabbix_metrics))
    if args.yes:
        send_zabbix_data(args.zabbix, zabbix_metrics)


# if this returns an object (not None!), then this process is allowed
# to run.  if it returns None, then this process should not run
# because another copy of it is probably already running on this
# machine.  we don't worry [much] about that process being stuck since
# zabbix will eventually notice that we haven't updated it in a while.
def acquire_baton():
    try:
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind(('localhost', BATON_PORT))
        return server_socket
    except:
        return None


if __name__ == '__main__':
    if sys.argv[1:] == ['test']:
        del sys.argv[1]
        unittest.main()
    else:
        baton = acquire_baton()
        if baton:
            main()
        else:
            print "didn't acquire the baton.  another %s process must still be running." % sys.argv[0]
            sys.exit(1)
